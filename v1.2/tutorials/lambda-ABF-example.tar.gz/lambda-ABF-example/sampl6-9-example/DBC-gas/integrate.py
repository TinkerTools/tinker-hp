import numpy as np
import os

os.system("grep 'dLambda' dyn.out | awk {'print $7'} > dlambda.out")

file = "dlambda.out"
filein = open(file, "r")
lines = filein.readlines(0)

nlambda = 20
dAdl = np.zeros(nlambda+1)

i = 0
for line in lines:
  dAdl[i]=line.rstrip('\n')
  i = i+1

dU = 0.0
dlambda = 1.0/nlambda
for i in range(nlambda-1):
  dU = dU + dlambda*(dAdl[i+1]+dAdl[i])/2

print(dU)
