#!/usr/bin/python
#
# extract the time series of the distance between two atoms along a tinker arc file
#
import csv
from numpy import *
from math import sqrt
from math import floor
#from image import *
#
# get parameters of the bins
#
hist_min = 2.0
hist_max = 5.2
num_bins = 100
size_bins = (hist_max-hist_min)/num_bins
#
list = [2.2,2.4,2.6,2.8,3.0,3.2,3.4,3.6,3.8,4.0,4.2,4.4,4.6,4.8,5.0]
#
for dist in list:
  #
  # create array of bins
  #
  data = zeros((num_bins))
  #
  # get data of the time series
  #
  cr = csv.reader(open("wham"+str(dist),"rb"),delimiter=' ',skipinitialspace=True)
  #
  for row in cr:
   temp = row[1]
   numbin = int((float(temp)-hist_min)/size_bins)
   if (numbin<num_bins) and (numbin>=0):
     data[numbin] = data[numbin]+1
  #
  #
  # write this to a new file
  #
  myfile = open("whamdist"+str(dist),"wb")
  cr2 = csv.writer(myfile,delimiter=' ')
  for i in range(0,num_bins):
    row =[]
    row.append(i+1)
    row.append(hist_min+i*size_bins)
    row.append(float(data[i]/20))
    cr2.writerow(row)

