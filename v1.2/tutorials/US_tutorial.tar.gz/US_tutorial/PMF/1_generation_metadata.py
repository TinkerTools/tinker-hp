#!/usr/bin/env python

# THIS SCRIPT AIMS AT GENERATING THE METADATA FILE
# WHICH IS REQUIRED BY THE WHAM EXECUTABLE

tab=["2.2", "2.4", "2.6", "2.8", "3.0", "3.2", "3.4", "3.6", "3.8", "4.0", "4.2", "4.4", "4.6", "4.8", "5.0"]		# The different windows
k = 20															# The spring constant *2 used in Tinker

out = open("metadata", "w")

for i in range(len(tab)):
	out.write("./wham{} {}  {} \n".format(tab[i],tab[i],k))	
	print("{} done !".format(tab[i]))

out.close()

