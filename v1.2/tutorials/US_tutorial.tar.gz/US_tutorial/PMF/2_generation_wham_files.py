#!/usr/bin/env python

import numpy as np

path = "../arcfiles/"													# The path where all the dynamics are
tab = ["2.2", "2.4", "2.6", "2.8", "3.0", "3.2", "3.4", "3.6", "3.8", "4.0",
       "4.2", "4.4", "4.6", "4.8", "5.0"]           # The different windows
num_frames = 4000														# The number of frames per traj
num_at1 = 2														# Label of the first atom
num_at2 = 20														# Label of the second atom
box = 30.															# The box length of the simulation (in A)

for i in range(len(tab)):
    out = open("wham"+str(tab[i]), "w")
    f = open(path+tab[i]+".arc")
    for j in range(num_frames):
        a = f.readline()
        b = a.split()
        num_ats = int(b[0])
        for k in range(num_ats):
            if k+1 == num_at1:
                a = f.readline()
                b = a.split()
                x_1 = float(b[2])
                y_1 = float(b[3])
                z_1 = float(b[4])
            elif k+1 == num_at2:
                a = f.readline()
                b = a.split()
                x_2 = float(b[2])
                y_2 = float(b[3])
                z_2 = float(b[4])
            else:
                f.readline()
        # PBC condition
        x_dist1 = np.abs(x_2-x_1)
        x_1 -= box
        x_dist2 = np.abs(x_2-x_1)
        if x_dist1 < x_dist2:
            x_1 += 2*box
            x_dist2 = np.abs(x_2-x_1)
            if x_dist1 < x_dist2:
                x_1 -= box
        y_dist1 = np.abs(y_2-y_1)
        y_1 -= box
        y_dist2 = np.abs(y_2-y_1)
        if y_dist1 < y_dist2:
            y_1 += 2*box
            y_dist2 = np.abs(y_2-y_1)
            if y_dist1 < y_dist2:
                y_1 -= box
        z_dist1 = np.abs(z_2-z_1)
        z_1 -= box
        z_dist2 = np.abs(z_2-z_1)
        if z_dist1 < z_dist2:
            z_1 += 2*box
            z_dist2 = np.abs(z_2-z_1)
            if z_dist1 < z_dist2:
                z_1 -= box
        dist = np.sqrt((x_2-x_1)**2 + (y_2-y_1)**2 + (z_2-z_1)**2)
        out.write("{} {} \n".format(j,dist))

        print("{}   {}/{} done !".format(tab[i],j+1,num_frames))

    f.close()
    out.close()
