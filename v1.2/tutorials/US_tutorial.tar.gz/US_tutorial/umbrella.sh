#!/bin/bash

tab="2.2 2.4 2.6 2.8 3.0 3.2 3.4 3.6 3.8 4.0 4.2 4.4 4.6 4.8 5.0"

for i in $tab; do
	if [ ! -d $i ]; then
		mkdir $i
	else
		rm -r $i
		mkdir $i
	fi
	cp complex.xyz dynamic.key $i/
	cd $i/
	sed -i "s/XXX/$i/g" dynamic.key
	cd ../
	echo "$i done !"
done

