set encoding iso_8859_1

set terminal pngcairo size 2400,1500 enhanced font 'Helvetica,30'                                   
set output 'Umbrellas.png'

set key off
set xlabel"End-to-end distance (\305)"
set ylabel'Histogram'
set xrange[2.0:5.2]
set yrange[0:40]
set xlabel font "Helvetica,60"
set ylabel font "Helvetica,60"
set grid

set style line 1 lt 1 lc rgb "blue" pt 5
set style line 2 lt 1 lc rgb "black" pt 5
set style line 3 lt 1 lc rgb "green" pt 5
set style line 4 lt 1 lc rgb "green" pt 7
set style line 5 lt 1 lc rgb "green" pt 9
set style line 6 lt 1 lc rgb "purple" pt 5
set style line 7 lt 1 lc rgb "purple" pt 9
set style line 8 lt 1 lc rgb "blue" 
set style line 9 lt 1 lc rgb "green"

plot 'whamdist2.2' u 2:3 w l linewidth 3.0 , \
     'whamdist2.4' u 2:3 w l linewidth 3.0 , \
     'whamdist2.6' u 2:3 w l linewidth 3.0 , \
     'whamdist2.8' u 2:3 w l linewidth 3.0 , \
     'whamdist3.0' u 2:3 w l linewidth 3.0 , \
     'whamdist3.2' u 2:3 w l linewidth 3.0 , \
     'whamdist3.4' u 2:3 w l linewidth 3.0 , \
     'whamdist3.6' u 2:3 w l linewidth 3.0 , \
     'whamdist3.8' u 2:3 w l linewidth 3.0 , \
     'whamdist4.0' u 2:3 w l linewidth 3.0 , \
     'whamdist4.2' u 2:3 w l linewidth 3.0 , \
     'whamdist4.4' u 2:3 w l linewidth 3.0 , \
     'whamdist4.6' u 2:3 w l linewidth 3.0 , \
     'whamdist4.8' u 2:3 w l linewidth 3.0 , \
     'whamdist5.0' u 2:3 w l linewidth 3.0 
set output



