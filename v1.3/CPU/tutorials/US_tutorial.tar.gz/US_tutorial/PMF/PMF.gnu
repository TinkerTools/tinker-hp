set encoding iso_8859_1

set terminal pngcairo size 2400,1500 enhanced font 'Helvetica,30'                                   
set output 'PMF.png'

set key on at 7.0,8.5 box width 3 height 2
set xlabel"End-to-end distance (\305)"
set ylabel'PMF (kcal/mol)'
set xrange[2.0:7.2]
set yrange[-0.5:9]
set xlabel font "Helvetica,60"
set ylabel font "Helvetica,60"
set xtics font "Helvetica,60"
set ytics font "Helvetica,60"
set grid

set style line 1 lt 1 lc rgb "blue" pt 5
set style line 2 lt 1 lc rgb "black" pt 5
set style line 3 lt 1 lc rgb "green" pt 5
set style line 4 lt 1 lc rgb "green" pt 7
set style line 5 lt 1 lc rgb "green" pt 9
set style line 6 lt 1 lc rgb "purple" pt 5
set style line 7 lt 1 lc rgb "purple" pt 9
set style line 8 lt 1 lc rgb "blue" 
set style line 9 lt 1 lc rgb "green"

plot 'out' w l lc rgb "green" linewidth 3.0 title "AMOEBA"

set output



